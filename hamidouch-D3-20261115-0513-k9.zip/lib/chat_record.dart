class ChatTurn {
  final String user;
  final String assistant;
  const ChatTurn(this.user, this.assistant);
  Map<String, String> toJson() => {'user': user, 'assistant': assistant};
  factory ChatTurn.fromJson(Object? value) {
    if (value is! Map || value['user'] is! String || value['assistant'] is! String) {
      throw const FormatException('Invalid completed turn');
    }
    return ChatTurn(value['user'] as String, value['assistant'] as String);
  }
}

class ChatArchive {
  final List<String> messages;
  final List<ChatTurn> turns;
  const ChatArchive(this.messages, this.turns);
  Map<String, Object> toJson() => {
    'version': 2,
    'messages': messages,
    'turns': turns.map((t) => t.toJson()).toList(),
  };
  factory ChatArchive.fromJson(Object? value) {
    if (value is! Map || (value['version'] != 1 && value['version'] != 2)) {
      throw const FormatException('Invalid archive version');
    }
    final rows = value['messages'];
    if (rows is! List || rows.any((r) => r is! String)) {
      throw const FormatException('Invalid displayed messages');
    }
    final rawTurns = value['version'] == 1 ? <Object?>[] : value['turns'];
    if (rawTurns is! List) throw const FormatException('Invalid turns');
    return ChatArchive(rows.cast<String>(), rawTurns.map(ChatTurn.fromJson).toList());
  }
}
