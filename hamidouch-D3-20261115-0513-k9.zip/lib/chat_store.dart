import 'dart:convert';
import 'dart:io';
import 'chat_record.dart';
import 'package:path_provider/path_provider.dart';

/// Private app storage, not encrypted. Stores displayed text, not model state.
class ChatStore {
  final File? archiveFile;
  ChatStore({this.archiveFile});
  Future<File> _file() async {
    if (archiveFile != null) return archiveFile!;
    final directory = await getApplicationSupportDirectory();
    return File('${directory.path}/hamidouch_chat_v1.json');
  }

  Future<ChatArchive> load() async {
    final file = await _file();
    if (!await file.exists()) return const ChatArchive([], []);
    if (await file.length() > 8 * 1024 * 1024) {
      throw const FormatException('Chat archive exceeds size limit');
    }
    final value = jsonDecode(await file.readAsString());
    return ChatArchive.fromJson(value);
  }

  Future<void> save(ChatArchive archive) async {
    final file = await _file();
    final encoded = jsonEncode(archive.toJson());
    if (utf8.encode(encoded).length > 8 * 1024 * 1024) {
      throw const FormatException('Chat archive exceeds size limit');
    }
    final temporary = File('${file.path}.writing');
    await temporary.writeAsString(encoded, flush: true);
    await temporary.rename(file.path);
  }
}
