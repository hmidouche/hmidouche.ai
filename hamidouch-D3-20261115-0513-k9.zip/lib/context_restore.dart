import 'package:llamadart/llamadart.dart';
import 'chat_record.dart';

void restoreCompletedTurns(ChatSession session, List<ChatTurn> turns) {
  session.reset();
  // Bound tokenization work; LocalAi checks the exact budget before sending.
  final recent = turns.length > 12 ? turns.sublist(turns.length - 12) : turns;
  for (final turn in recent) {
    session.addMessage(LlamaChatMessage.fromText(role: LlamaChatRole.user, text: turn.user));
    session.addMessage(LlamaChatMessage.fromText(role: LlamaChatRole.assistant, text: turn.assistant));
  }
}
