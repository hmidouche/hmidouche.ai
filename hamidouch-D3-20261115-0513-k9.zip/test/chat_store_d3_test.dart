import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:hamidouch_ai/chat_record.dart';
import 'package:hamidouch_ai/chat_store.dart';

void main() {
  late Directory directory;
  late File file;
  late ChatStore store;
  setUp(() async {
    directory = await Directory.systemTemp.createTemp('hamidouch_d3_');
    file = File('${directory.path}/chat.json');
    store = ChatStore(archiveFile: file);
  });
  tearDown(() async => directory.delete(recursive: true));
  test('Missing archive starts empty', () async {
    final archive = await store.load();
    expect(archive.messages, isEmpty);
    expect(archive.turns, isEmpty);
  });
  test('Completed Arabic turn survives a fresh store instance', () async {
    await store.save(const ChatArchive(['اسمي علي', 'حميدوش: أهلًا علي'], [ChatTurn('اسمي علي', 'أهلًا علي')]));
    final restored = await ChatStore(archiveFile: file).load();
    expect(restored.messages.length, 2);
    expect(restored.turns.single.user, 'اسمي علي');
    expect(restored.turns.single.assistant, 'أهلًا علي');
  });
  test('Legacy archive remains visible without guessed roles', () async {
    await file.writeAsString(jsonEncode({'version': 1, 'messages': ['نص قديم']}));
    final archive = await store.load();
    expect(archive.messages, ['نص قديم']);
    expect(archive.turns, isEmpty);
  });
  test('Clearing persists and replacement saves work', () async {
    await store.save(const ChatArchive(['old'], [ChatTurn('q', 'a')]));
    await store.save(const ChatArchive([], []));
    final archive = await store.load();
    expect(archive.messages, isEmpty);
    expect(archive.turns, isEmpty);
  });
  test('Corrupt archive is rejected without rewriting it', () async {
    await file.writeAsString('{broken');
    await expectLater(store.load(), throwsFormatException);
    expect(await file.readAsString(), '{broken');
  });
  test('Malformed roles cannot become restored turns', () {
    expect(() => ChatArchive.fromJson({'version': 2, 'messages': [], 'turns': [{'user': 'q', 'assistant': 7}]}), throwsFormatException);
  });
}
