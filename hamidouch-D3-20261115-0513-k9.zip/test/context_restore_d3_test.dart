import 'package:flutter_test/flutter_test.dart';
import 'package:llamadart/llamadart.dart';
import 'package:hamidouch_ai/chat_record.dart';
import 'package:hamidouch_ai/context_restore.dart';

class MemorySession implements ChatSession {
  final rows = <LlamaChatMessage>[];
  @override
  void reset({bool keepSystemPrompt = true}) => rows.clear();
  @override
  void addMessage(LlamaChatMessage message) => rows.add(message);
  @override
  dynamic noSuchMethod(Invocation invocation) => super.noSuchMethod(invocation);
}

void main() {
  test('Restore replaces old state and seeds alternating message roles', () {
    final session = MemorySession();
    final turns = [const ChatTurn('اسمي علي', 'مرحبًا علي')];
    restoreCompletedTurns(session, turns);
    restoreCompletedTurns(session, turns);
    expect(session.rows.length, 2);
    expect(session.rows[0].role, LlamaChatRole.user);
    expect(session.rows[1].role, LlamaChatRole.assistant);
  });
  test('Only the latest twelve completed turns are seeded', () {
    final session = MemorySession();
    final turns = List.generate(20, (i) => ChatTurn('q$i', 'a$i'));
    restoreCompletedTurns(session, turns);
    expect(session.rows.length, 24);
    expect(turns.length, 20);
    restoreCompletedTurns(session, []);
    expect(session.rows, isEmpty);
  });
}
