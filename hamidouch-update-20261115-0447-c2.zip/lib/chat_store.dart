import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

/// Private app storage, not encrypted. Stores displayed text, not model state.
class ChatStore {
  Future<File> _file() async {
    final directory = await getApplicationSupportDirectory();
    return File('${directory.path}/hamidouch_chat_v1.json');
  }

  Future<List<String>> load() async {
    final file = await _file();
    if (!await file.exists()) return <String>[];
    if (await file.length() > 8 * 1024 * 1024) {
      throw const FormatException('Chat archive exceeds size limit');
    }
    final value = jsonDecode(await file.readAsString());
    if (value is! Map<String, dynamic> || value['version'] != 1) {
      throw const FormatException('Invalid chat archive');
    }
    final rows = value['messages'];
    if (rows is! List || rows.any((row) => row is! String)) {
      throw const FormatException('Invalid chat messages');
    }
    return rows.cast<String>();
  }

  Future<void> save(List<String> messages) async {
    final file = await _file();
    final encoded = jsonEncode({'version': 1, 'messages': messages});
    if (utf8.encode(encoded).length > 8 * 1024 * 1024) {
      throw const FormatException('Chat archive exceeds size limit');
    }
    final temporary = File('${file.path}.writing');
    await temporary.writeAsString(encoded, flush: true);
    await temporary.rename(file.path);
  }
}
